﻿using System;
namespace Animal
{
    public class Mammal : Animal
    {

        public Mammal(string name) : base (name)
        {
            
        }
        public string toString()
        {
            return " Mammal [ Animal [name = " + getName() + " ] ]";
        }
    }
}

