﻿using System;
namespace Animal
{
    public class Dog : Mammal
    {
        public Dog(string name) : base (name)
        {

        }
        public void greets()
        {
            Console.WriteLine("Woof");
        }
        public void greets(Dog another)
        {
            Console.WriteLine("Wooooof");
        }
        public string toString()
        {
            return " Dog[ Mammal [ Animal [name = " + getName() + " ] ] ] ";
        }
    }
}

