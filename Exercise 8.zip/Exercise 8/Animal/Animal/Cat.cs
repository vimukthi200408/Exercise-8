﻿using System;
namespace Animal
{
    public class Cat : Mammal
    {
        public Cat(string name) : base (name)
        {

        }
        public void greets()
        {
            Console.WriteLine("Meow");
        }
        public string toString()
        {
            return " Cat [ Mammal [ Animal [name = " + getName() + " ] ] ] ";
        }
    }
}

