﻿using System;
namespace Shapes
{
    public class Shape
    {
        private string color = "red";
        private Boolean filled = true;

        public Shape()
        {
        }
        public Shape(string color, Boolean filled)
        {
            this.color = color;
            this.filled = filled;

        }
        public string getColor()
        {
            return color;
        }
        public void setColor(string color)
        {
            this.color = color;
        }
        public Boolean isFilled()
        {
            return filled;
        }
        public void setFilled(Boolean filled)
        {
            this.filled = filled;
        }
        public string toString()
        {
            return " Shape[color = "+color+" ,filled = "+filled+" ] ";
        }
    }
}

