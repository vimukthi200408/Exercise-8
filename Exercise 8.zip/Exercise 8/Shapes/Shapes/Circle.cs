﻿using System;
namespace Shapes
{
    public class Circle : Shape
    {
        private double radius = 1.0;

        public Circle()
        {

        }
        public Circle(double radius)
        {
            this.radius = radius;
        }
        public Circle(double radius, string color, Boolean filled) : base(color, filled)
        {
            this.radius = radius;
        }
        public double getRadius()
        {
            return radius;
        }
        public void setRadius(double radius)
        {
            this.radius = radius;
        }
        public double getArea()
        {
            double area;
            area = (22 / 7) * radius * radius;
            return area;
        }
        public double getPerimeter()
        {
            double per;
            per = 2 * (22 / 7) * radius;
            return per;
        }

        public string toString()
        {
            return "Circle [Shape[color = " + getColor() + " , filled = " + isFilled() + " ]";
        }
    }
    
}

